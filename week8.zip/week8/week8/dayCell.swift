//
//  dayCell.swift
//  week8
//
//  Created by Appzoc on 03/08/17.
//  Copyright © 2017 appzoc. All rights reserved.
//

import UIKit

class dayCell: UICollectionViewCell {
    @IBOutlet weak var day: UILabel!
    
}
