//
//  calenderCell.swift
//  week8
//
//  Created by Appzoc on 02/08/17.
//  Copyright © 2017 appzoc. All rights reserved.
//

import UIKit

class calenderCell: UICollectionViewCell {
    @IBOutlet weak var month: UILabel!
    
}
