//
//  Car1+CoreDataClass.swift
//  week9
//
//  Created by Appzoc on 11/08/17.
//  Copyright © 2017 appzoc. All rights reserved.
//

import Foundation
import CoreData


public class Car1: NSManagedObject {

}
