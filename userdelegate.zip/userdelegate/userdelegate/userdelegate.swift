//
//  userdelegate.swift
//  userdelegate
//
//  Created by Appzoc on 25/08/17.
//  Copyright © 2017 appzoc. All rights reserved.
//

import UIKit

protocol userDelegate: class {
    func changeBackgroundColor(_ color: UIColor?)
}
